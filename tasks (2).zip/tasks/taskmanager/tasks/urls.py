# tasks/urls.py
from django.urls import path
from . import views

app_name = 'tasks'

urlpatterns = [
    path('', views.task_list, name='task_list'),            # task list (home)
    path('add/', views.task_create, name='task_add'),       # add task
    path('edit/<int:pk>/', views.task_update, name='task_edit'),  # edit task
    path('delete/<int:pk>/', views.task_delete, name='task_delete'), # delete task (confirm)
]
