<?php
require 'db.php';

$stmt = $pdo->query("SELECT * FROM profiles ORDER BY id DESC");
$profiles = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Profile List</title>
</head>
<body>
    <h2>Profile List</h2>
    <a href="index.php">Add New Profile</a><br><br>
    <table border="1" cellpadding="5">
        <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Headline</th>
            <th>Summary</th>
            <th>Position</th>
            <th>Year</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($profiles as $profile): ?>
        <tr>
            <td><?php echo htmlspecialchars($profile['first_name']); ?></td>
            <td><?php echo htmlspecialchars($profile['last_name']); ?></td>
            <td><?php echo htmlspecialchars($profile['email']); ?></td>
            <td><?php echo htmlspecialchars($profile['headline']); ?></td>
            <td><?php echo htmlspecialchars($profile['summary']); ?></td>
            <td><?php echo htmlspecialchars($profile['position']); ?></td>
            <td><?php echo htmlspecialchars($profile['year']); ?></td>
            <td>
                <a href="edit_profile.php?id=<?php echo $profile['id']; ?>">Edit</a> |
                <a href="delete_profile.php?id=<?php echo $profile['id']; ?>" onclick="return confirm('Are you sure?')">Delete</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
