<?php
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $headline = $_POST['headline'];
    $summary = $_POST['summary'];
    $position = $_POST['position'];
    $year = $_POST['year'];
    $details = $_POST['details'];

    $stmt = $pdo->prepare("INSERT INTO profiles (first_name, last_name, email, headline, summary, position, year, details)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$first_name, $last_name, $email, $headline, $summary, $position, $year, $details]);

    header("Location: list_profiles.php");
    exit;
}
?>
