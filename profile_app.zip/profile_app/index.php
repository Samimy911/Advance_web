<?php
$profile_name = "Chuck";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add Profile for <?php echo $profile_name; ?></title>
</head>
<body>
    <h2>Add Profile for <?php echo $profile_name; ?></h2>
    <form action="add_profile.php" method="post">
        First Name: <input type="text" name="first_name" required><br><br>
        Last Name: <input type="text" name="last_name" required><br><br>
        Email: <input type="email" name="email" required><br><br>
        Headline: <input type="text" name="headline" required><br><br>
        Summary: <textarea name="summary"></textarea><br><br>
        Position:
        <select name="position">
            <option value="Manager">Manager</option>
            <option value="Developer">Developer</option>
            <option value="Designer">Designer</option>
            <option value="Intern">Intern</option>
        </select><br><br>
        Year: <input type="number" name="year" min="1900" max="2100"><br><br>
        Details: <input type="text" name="details"><br><br>
        <button type="submit">Add</button>
        <button type="reset">Cancel</button>
    </form>
</body>
</html>
