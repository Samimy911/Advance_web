<?php
require 'db.php';
$id = $_GET['id'] ?? null;

if (!$id) {
    header("Location: list_profiles.php");
    exit;
}

// Fetch existing profile
$stmt = $pdo->prepare("SELECT * FROM profiles WHERE id = ?");
$stmt->execute([$id]);
$profile = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$profile) {
    die("Profile not found");
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $stmt = $pdo->prepare("UPDATE profiles SET first_name=?, last_name=?, email=?, headline=?, summary=?, position=?, year=?, details=? WHERE id=?");
    $stmt->execute([
        $_POST['first_name'],
        $_POST['last_name'],
        $_POST['email'],
        $_POST['headline'],
        $_POST['summary'],
        $_POST['position'],
        $_POST['year'],
        $_POST['details'],
        $id
    ]);
    header("Location: list_profiles.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Profile</title>
</head>
<body>
    <h2>Edit Profile for <?php echo htmlspecialchars($profile['first_name']); ?></h2>
    <form method="post">
        First Name: <input type="text" name="first_name" value="<?php echo htmlspecialchars($profile['first_name']); ?>"><br><br>
        Last Name: <input type="text" name="last_name" value="<?php echo htmlspecialchars($profile['last_name']); ?>"><br><br>
        Email: <input type="email" name="email" value="<?php echo htmlspecialchars($profile['email']); ?>"><br><br>
        Headline: <input type="text" name="headline" value="<?php echo htmlspecialchars($profile['headline']); ?>"><br><br>
        Summary: <textarea name="summary"><?php echo htmlspecialchars($profile['summary']); ?></textarea><br><br>
        Position:
        <select name="position">
            <option value="Manager" <?php if($profile['position']=='Manager') echo 'selected'; ?>>Manager</option>
            <option value="Developer" <?php if($profile['position']=='Developer') echo 'selected'; ?>>Developer</option>
            <option value="Designer" <?php if($profile['position']=='Designer') echo 'selected'; ?>>Designer</option>
            <option value="Intern" <?php if($profile['position']=='Intern') echo 'selected'; ?>>Intern</option>
        </select><br><br>
        Year: <input type="number" name="year" value="<?php echo htmlspecialchars($profile['year']); ?>"><br><br>
        Details: <input type="text" name="details" value="<?php echo htmlspecialchars($profile['details']); ?>"><br><br>
        <button type="submit">Update</button>
        <a href="list_profiles.php">Cancel</a>
    </form>
</body>
</html>
